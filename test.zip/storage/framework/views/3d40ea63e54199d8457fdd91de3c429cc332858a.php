<script src="../js/jquery-1.10.1.min.js"></script>
<script src="bootstrap-datepicker.js"></script>
<script src="../js/jquery.validate.min.js" ></script>
<script src="../js/framework7.js"></script>
<script src="../js/jquery.swipebox.js"></script>
<script src="../js/jquery.fitvids.js"></script>
<script src="../js/email.js"></script>
<script src="../js/audio.min.js"></script>
<script src="../js/my-app.js"></script>
<script>
$(document).ready(function(){
 $("#home_re").click(function(){
    window.location.href = 'http://localhost/SchoolApp/';
	
 });
  $("#staff_re").click(function(){
    window.location.href = 'teacher';
	
 });
   $("#class_re").click(function(){
    window.location.href = 'class_creation';
	
 });
  $("#level_re").click(function(){
    window.location.href = 'section_creation';
	
 });
});
</script><?php /**PATH C:\xampp\htdocs\test_app\resources\views/include/editscript.blade.php ENDPATH**/ ?>