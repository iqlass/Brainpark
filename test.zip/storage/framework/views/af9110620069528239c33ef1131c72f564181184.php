<script src="js/jquery-1.10.1.min.js"></script>
<script src="bootstrap-datepicker.js"></script>
<script src="js/jquery.validate.min.js" ></script>
<script src="js/framework7.js"></script>
<script src="js/jquery.swipebox.js"></script>
<script src="js/jquery.fitvids.js"></script>
<script src="js/email.js"></script>
<script src="js/audio.min.js"></script>
<script src="js/my-app.js"></script>
<script>
$(document).ready(function(){
 $("#home_re").click(function(){
    window.location.href = 'http://localhost/test_app/';
	
 });
  $("#staff_re").click(function(){
    window.location.href = 'teacher';
	
 });
   $("#class_re").click(function(){
    window.location.href = 'class_creation';
	
 });
  $("#level_re").click(function(){
    window.location.href = 'section_creation';
	
 });
   $("#add_student").click(function(){
    window.location.href = 'studentcration';
	
 });
  $("#att_student").click(function(){
    window.location.href = 'manage_attendance_view';
	
 });
   $("#create_fee").click(function(){
    window.location.href = 'create_fee';
	
 });
   $("#login").click(function(){
    window.location.href = 'emp_login';
	
 });
   $("#bill_carete").click(function(){
    window.location.href = 'met_bill';
	
 });
});

</script>
  <?php /**PATH C:\xampp\htdocs\test_app\resources\views/include/script.blade.php ENDPATH**/ ?>