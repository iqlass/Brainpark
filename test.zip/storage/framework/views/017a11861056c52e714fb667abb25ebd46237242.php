   <div class="navbarpages">
                            <div class="navbar_left">
                                <div class="logo_text">ArtSport</div>
                            </div>
			    <div class="navbar_right navbar_right_menu">
				<a href="#" data-panel="left" class="open-panel"><img src="images/icons/white/menu.png" alt="" title="" /></a>
			    </div>			
			    <div class="navbar_right">
				<a href="#" data-panel="right" class="open-panel"><img src="images/icons/white/user.png" alt="" title="" /></a>
			    </div>
			    
                        </div><?php /**PATH C:\xampp\htdocs\test_app\resources\views/include/edit_top_name.blade.php ENDPATH**/ ?>